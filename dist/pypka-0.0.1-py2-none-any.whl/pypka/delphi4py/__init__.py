name = "delphi4py"

from delphi4py import Delphi
from . import readFiles
