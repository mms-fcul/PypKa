from pypka import Titration

# Assignment of global variables
parameters = checkParsedInput()

Titration(None, parameters, sites=None)

print 'CLI exited successfully'
